var Scuba_diver,Swordfish,Playing_Charecter;
var Plastic1,Plastic2,Plastic3;
var Oil1,Oil2,Oil3;
var oilCan1,oilCan2,oilCan3;
var Heart1,Heart2,Heart3,Heart_1;
var background,Ocean;
var obstacle;

function preload() {
 background1 = loadImage("Background1.jpg");
 Scuba_diver = loadImage("ScubaDiver.png");
 Swordfish = loadImage("Swordfish_1.jpg");
 obstacle1 = loadImage("PLasticBag.png");
 Heart_1 = loadImage("Full_heart.png");
 obstacle2 = loadImage("Oil.png");
 obstacle3 = loadImage("OilCan1.png");
 shooting_sound=loadSound("mixkit-laser-game-over-1946.wav");
  HeartDestroy_Sound = loadSound("mixkit-arcade-retro-game-over-213.wav");

}

function setup() {
  createCanvas(windowWidth,windowHeight);
  
  edges=createEdgeSprites();
  Ocean = createSprite(10,10,windowWidth,windowHeight);
  Ocean.addImage("ground",background1);
  
  Playing_Charecter = createSprite(100,100,50,50);
  Playing_Charecter.addImage("Player",Scuba_diver);
  Playing_Charecter.scale=0.3;
  Playing_Charecter.velocityY = 0.5;
  Playing_Charecter.debug = false;
  Playing_Charecter.setCollider("rectangle",0,0,40,40);
  Heart1 = createSprite(20,530,10,10);
  Heart1.addImage("Heart",Heart_1);
  Heart1.scale = 0.1;
  
  Heart2 = createSprite(50,530,10,10);
  Heart2.addImage("Heart",Heart_1);
  Heart2.scale = 0.1;
  
  Heart3 = createSprite(80,530,10,10);
  Heart3.addImage("Heart",Heart_1);
  Heart3.scale = 0.1;
  
  obstacleGroup = new Group();
  score = 0;
}
function draw() {
  background("background1");
  text("Score :"+score,500,10);
  
  if(keyDown("left_arrow")){
     Playing_Charecter.x= Playing_Charecter.x-5;
  }
  if(keyDown("right_arrow")){
     Playing_Charecter.x= Playing_Charecter.x+5;
  }
   if(keyDown("space")){  
     shooting_sound.play();
     score = score+2;
     obstacleGroup.destroyEach();
  }
  
  if(Playing_Charecter.collide(edges[3])){                              Playing_Charecter.y=10;
     Playing_Charecter.velocityY=1;                                
    }
  
  if(obstacleGroup.isTouching(Playing_Charecter)) {
    Heart1.destroy();
    HeartDestroy_Sound.play();
  }
  
  spawnObstacles();
  drawSprites();
  textSize(30)
  text("Score:"+score, 450,20);
}
function spawnObstacles(){
 if (frameCount % 100 === 0){
   var obstacle = createSprite(300,200,10,40);
   obstacle.velocityX = -3;
   obstacle.y = Math.round(random(200,300));

    // //generate random obstacles
    var rand = Math.round(random(1,3));
    switch(rand) {
      case 1: obstacle.addImage(obstacle1);
              break;
      case 2: obstacle.addImage(obstacle2);
              break;
      case 3: obstacle.addImage(obstacle3);
              break;
      default: break;
    }
   obstacleGroup.add(obstacle);
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.1;
   obstacle.depth= Playing_Charecter.depth;
  Playing_Charecter.depth=Playing_Charecter.depth+1;
 }
}